import React from 'react'

const Change = () => {
  return (
    <div className=' h-32 overflow-y-clip text-white uppercase font-mono'>
    <h1 className='text-[500px] h-2'>CHANGE</h1>
    </div>
  )
}

export default Change
