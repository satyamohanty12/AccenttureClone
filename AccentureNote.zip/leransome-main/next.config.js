/** @type {import('next').NextConfig} */
const nextConfig = {}

module.exports = nextConfig
nextConfig.images = {
  domains: ['1000logos.net'],
}
